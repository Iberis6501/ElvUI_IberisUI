# ElvUI IberisUI

## [v2.05](https://github.com/Iberis6501/ElvUI_IberisUI/tree/v2.05) (2026-05-10)
[Full Changelog](https://github.com/Iberis6501/ElvUI_IberisUI/compare/v2.04...v2.05) [Previous Releases](https://github.com/Iberis6501/ElvUI_IberisUI/releases)

- chore: bump version to v2.05 (서약선 SV 변경 반영)  
    Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>  
- feat: 서약선 캐릭터 게임 내 변경 사항 반영  
    WTF/Account/CGS7315/SavedVariables에서 서약선 캐릭터의 게임 내 변경 추출:  
    - HidingBar 프로필  
      - bar size 15 → 20  
      - LibDBIcon10\_RaidBook mbtnSetting 추가  
    - BuiMiddleDTPanel 슬롯 2: LDB\_iWillRemember\_MinimapButton → LDB\_RaidBook  
    추가:  
    - README.md changelog v2.05 항목  
    - INVEN\_POST.html 패치 내역 v2.05 항목  
    - assets/ElvUI\_IberisUI\_v2.05.zip (인벤 게시물 첨부용)  
    Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>  
- chore: .markdownlint.json을 .pkgmeta ignore에서 제외  
    CF App 자동 업데이트 시 \_anniversary\_에서 .markdownlint.json이 사라져  
    markdownlint 경고가 폭발하는 문제 영구 해결.  
    다음 빌드부터 zip에 포함되어 사용자 PC에서도 보존됨.  
    26 byte 짜리 작은 설정 파일이라 사용자 영향 없음.  
    Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>  
- docs: 인벤 게시물용 자료 추가 (assets/)  
    - assets/INVEN\_POST.html: 인벤(inven.co.kr) 게시물 본문 HTML  
      v2.04 README/Description 내용 반영, 이미지/동영상 링크 유지  
      인벤 에디터 spacing quirk 대응 (소스 빈 줄/주석/standalone <br> 제거)  
    - assets/ElvUI\_IberisUI\_v2.04.zip: 인벤 게시물 첨부용 v2.04 zip  
      CurseForge 자동 배포만으론 인벤 게시물이 갱신 안 되어 별도 첨부 필요  
    Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>  
- docs: # English / # 한국어 헤딩 제거 (섹션 제목으로 언어 구분이 충분)  
    Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>  
