# ElvUI IberisUI

## [v2.04](https://github.com/Iberis6501/ElvUI_IberisUI/tree/v2.04) (2026-05-10)
[Full Changelog](https://github.com/Iberis6501/ElvUI_IberisUI/compare/v2.03...v2.04) [Previous Releases](https://github.com/Iberis6501/ElvUI_IberisUI/releases)

- chore: bump version to v2.04 (CurseForge 정책 추가 대응 반영)  
    Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>  
- docs: CurseForge 모더레이션 정책 추가 대응  
    - 영문/한글 ## Links 두 섹션 → 페이지 최하단 통합 ## Links / 링크 한 곳으로  
      - cross-hosting 링크는 페이지 하단에 위치해야 한다는 정책 준수  
    - Installation Step 1 — ElvUI 다운로드 imperative 톤 다운  
      - "Download it directly from..." → "is distributed through its official site"  
    - Known Issues 인라인 GitHub Issues 링크 제거 → 하단 Links 섹션 참조  
    - README.md changelog v2.04 항목 추가  
    Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>  
